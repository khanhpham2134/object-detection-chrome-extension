import * as tf from '@tensorflow/tfjs';

let model;
let keyword = "";
let videoElement = null;
let canvas;
let ctx;
let detectionInterval;
let classNames = {}; 

document.addEventListener("DOMContentLoaded", () => {
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    
    document.getElementById("shareScreen").addEventListener("click", startScreenCapture);
    document.getElementById("start").addEventListener("click", startDetection);
    document.getElementById("stop").addEventListener("click", stopDetection);
    
    document.getElementById("start").disabled = true;
    document.getElementById("stop").disabled = true;
    
    Promise.all([loadModel(), loadClassNames()])
        .then(() => {
            document.getElementById("modelStatus").textContent = "Model loaded successfully!";
        })
        .catch(error => {
            console.error("Initialization error:", error);
            document.getElementById("modelStatus").textContent = "Error loading model: " + error.message;
            document.getElementById("modelStatus").style.color = "#db4437";
        });
    
    chrome.storage.local.get("objectKeyword", (data) => {
        if (data.objectKeyword) {
            keyword = data.objectKeyword.toLowerCase();
            console.log("Detecting:", keyword);
            
            document.title = `Detecting: ${keyword}`;
            const keywordDisplay = document.getElementById("keywordDisplay");
            if (keywordDisplay) {
                keywordDisplay.textContent = `Looking for: ${keyword}`;
            }
        } else {
            console.warn("No object keyword found in storage.");
        }
    });
});

async function loadClassNames() {
    try {
        const response = await fetch(chrome.runtime.getURL('../yolo11n_web_model/metadata.yaml'));
        const yamlText = await response.text();
        
        const namesSection = yamlText.split('names:')[1].split('\n\n')[0];
        const nameLines = namesSection.split('\n').filter(line => line.trim() !== '');
        
        nameLines.forEach(line => {
            const match = line.match(/\s+(\d+):\s+(.*)/);
            if (match) {
                const classId = parseInt(match[1]);
                const className = match[2].trim();
                classNames[classId] = className;
            }
        });
        
        console.log("Class names loaded:", Object.keys(classNames).length);
        return classNames;
    } catch (error) {
        console.error("Error loading class names:", error);
    }
}

async function loadModel() {
    try {
        document.getElementById("modelStatus").textContent = "Loading model...";
        
        model = await tf.loadGraphModel(chrome.runtime.getURL('../yolo11n_web_model/model.json'), {
            fetchFunc: (url, init) => {
                return fetch(url, {
                    ...init,
                    cache: 'no-store' 
                });
            }
        });
        console.log("YOLO Model Loaded Successfully");
        return model;
    } catch (error) {
        console.error("Error loading YOLO model:", error);
        document.getElementById("errorMessage").textContent = `Error loading model: ${error.message}`;
        document.getElementById("errorMessage").style.display = "block";
        throw error;
    }
}

async function startScreenCapture() {
    try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ 
            video: { cursor: "always" },
            audio: false 
        });
        
        videoElement = document.getElementById("video");
        videoElement.srcObject = stream;
        
        stream.getVideoTracks()[0].onended = () => {
            stopDetection();
            console.log("Screen sharing ended by user");
        };
        
        const videoTrack = stream.getVideoTracks()[0];
        const settings = videoTrack.getSettings();
        
        const originalWidth = settings.width || 1920;
        const originalHeight = settings.height || 1080;
        
        videoElement.onloadedmetadata = () => {
            videoElement.width = originalWidth;
            videoElement.height = originalHeight;
            
            canvas.width = originalWidth;
            canvas.height = originalHeight;
            
            console.log("Screen sharing started with resolution:", canvas.width, "x", canvas.height);
            document.getElementById("start").disabled = false;
            
            canvas.style.width = "100%";
            canvas.style.height = "auto";
            canvas.style.maxHeight = "80vh";
        };
    } catch (err) {
        console.error("Error accessing screen sharing:", err);
        document.getElementById("errorMessage").textContent = `Error accessing screen sharing: ${err.message}`;
        document.getElementById("errorMessage").style.display = "block";
    }
}

async function startDetection() {
    if (!model) {
        document.getElementById("errorMessage").textContent = "Model not loaded yet. Please wait.";
        document.getElementById("errorMessage").style.display = "block";
        return;
    }
    if (!videoElement || videoElement.videoWidth === 0 || videoElement.videoHeight === 0) {
        document.getElementById("errorMessage").textContent = "Screen sharing not properly started or video not available.";
        document.getElementById("errorMessage").style.display = "block";
        return;
    }

    document.getElementById("errorMessage").style.display = "none";
    
    document.getElementById("start").disabled = true;
    document.getElementById("stop").disabled = false;

    const originalWidth = videoElement.videoWidth;
    const originalHeight = videoElement.videoHeight;
    
    canvas.width = originalWidth;
    canvas.height = originalHeight;
    
    detectionInterval = setInterval(async () => {
        try {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

            const modelWidth = 640;
            const modelHeight = 640;
            
            tf.engine().startScope();
            
            const [inputTensor, paddingInfo] = tf.tidy(() => {
                const img = tf.browser.fromPixels(canvas);
                
                const [h, w] = img.shape.slice(0, 2);
                
                const scale = Math.min(modelWidth / w, modelHeight / h);
                const newWidth = Math.round(w * scale);
                const newHeight = Math.round(h * scale);
                
                const resized = tf.image.resizeBilinear(img, [newHeight, newWidth]);
                
                const padTop = Math.floor((modelHeight - newHeight) / 2);
                const padLeft = Math.floor((modelWidth - newWidth) / 2);
                const padBottom = modelHeight - newHeight - padTop;
                const padRight = modelWidth - newWidth - padLeft;
                
                const padded = tf.pad(resized, [
                    [padTop, padBottom],
                    [padLeft, padRight],
                    [0, 0]
                ]);
                
                return [
                    padded.div(255.0).expandDims(0),
                    { 
                        scale: scale,
                        padLeft: padLeft, 
                        padTop: padTop, 
                        originalShape: [h, w] 
                    }
                ];
            });
            
            const outputs = await model.execute(inputTensor);
            
            const processedDetections = [];
            
            try {
                let transposed, boxes, scores, classes, nms, boxes_data, scores_data, classes_data;
                
                try {
                    [transposed, boxes, scores, classes] = tf.tidy(() => {
                        const trans = tf.transpose(outputs, [0, 2, 1]);
                        
                        const w = trans.slice([0, 0, 2], [-1, -1, 1]);
                        const h = trans.slice([0, 0, 3], [-1, -1, 1]);
                        const x1 = tf.sub(trans.slice([0, 0, 0], [-1, -1, 1]), tf.div(w, 2));
                        const y1 = tf.sub(trans.slice([0, 0, 1], [-1, -1, 1]), tf.div(h, 2));
                        const boxesResult = tf.concat(
                            [
                                y1, x1,
                                tf.add(y1, h),
                                tf.add(x1, w),
                            ],
                            2
                        ).squeeze();
                        
                        const numClasses = 80;
                        const rawScores = trans.slice([0, 0, 4], [-1, -1, numClasses]).squeeze(0);
                        
                        tf.keep(trans);
                        tf.keep(boxesResult);
                        const maxScores = rawScores.max(1);
                        const classIndices = rawScores.argMax(1);
                        tf.keep(maxScores);
                        tf.keep(classIndices);
                        
                        return [trans, boxesResult, maxScores, classIndices];
                    });
                    
                    const confidenceThreshold = 0.45;
                    const iouThreshold = 0.2;
                    nms = await tf.image.nonMaxSuppressionAsync(
                        boxes, scores, 100, confidenceThreshold, iouThreshold
                    );
                    
                    boxes_data = boxes.gather(nms, 0).dataSync();
                    scores_data = scores.gather(nms, 0).dataSync();
                    classes_data = classes.gather(nms, 0).dataSync();
                    
                    for (let i = 0; i < scores_data.length; i++) {
                        const score = scores_data[i];
                        const classId = classes_data[i];
                        const className = classNames[classId] || `Unknown (${classId})`;
                        
                        const y1 = boxes_data[i * 4];
                        const x1 = boxes_data[i * 4 + 1];
                        const y2 = boxes_data[i * 4 + 2];
                        const x2 = boxes_data[i * 4 + 3];
                        
                        processedDetections.push({
                            box: [x1, y1, x2, y2],
                            score: score,
                            class: classId,
                            className: className
                        });
                        
                        console.log(`Detection: ${className} (${(score * 100).toFixed(2)}%), box: [${x1.toFixed(1)}, ${y1.toFixed(1)}, ${x2.toFixed(1)}, ${y2.toFixed(1)}]`);
                    }
                } finally {
                    if (transposed && !transposed.isDisposed) transposed.dispose();
                    if (boxes && !boxes.isDisposed) boxes.dispose();
                    if (scores && !scores.isDisposed) scores.dispose();
                    if (classes && !classes.isDisposed) classes.dispose();
                    if (nms && !nms.isDisposed) nms.dispose();
                }
            } catch (err) {
                console.error("Error processing model output:", err);
            } finally {
                if (outputs && !outputs.isDisposed) {
                    outputs.dispose();
                }
                
                tf.engine().endScope();
            }
            
            drawDetections(processedDetections, paddingInfo);
            
        } catch (error) {
            console.error("Error during object detection:", error);
            clearInterval(detectionInterval);
            document.getElementById("errorMessage").textContent = `Detection error: ${error.message}`;
            document.getElementById("errorMessage").style.display = "block";
            document.getElementById("start").disabled = false;
            document.getElementById("stop").disabled = true;
        }
    }, 500);
}

function drawDetections(detections, paddingInfo) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    const { scale, padLeft, padTop, originalShape } = paddingInfo;
    const [originalHeight, originalWidth] = originalShape;
    
    let detectionCount = 0;
    let keywordMatchCount = 0;
    
    const colors = [
        "#FF3838", "#FF9D97", "#FF701F", "#FFB21D", "#CFD231", 
        "#48F90A", "#92CC17", "#3DDB86", "#1A9334", "#00D4BB", 
        "#2C99A8", "#00C2FF", "#344593", "#6473FF", "#0018EC", 
        "#8438FF", "#520085", "#CB38FF", "#FF95C8", "#FF37C7"
    ];
    
    const fontSize = Math.max(Math.round(Math.max(canvas.width, canvas.height) / 40), 14);
    ctx.font = `${fontSize}px Arial`;
    ctx.textBaseline = "top";

    for (const detection of detections) {
        detectionCount++;
        
        const isKeywordMatch = keyword && detection.className.toLowerCase().includes(keyword.toLowerCase());
        if (isKeywordMatch) keywordMatchCount++;
        
        let [x1, y1, x2, y2] = detection.box;
        
        const unpadX1 = x1 - padLeft;
        const unpadY1 = y1 - padTop;
        const unpadX2 = x2 - padLeft;
        const unpadY2 = y2 - padTop;
        
        const originalX1 = unpadX1 / scale;
        const originalY1 = unpadY1 / scale;
        const originalX2 = unpadX2 / scale;
        const originalY2 = unpadY2 / scale;
        
        const canvasX1 = (originalX1 / originalWidth) * canvas.width;
        const canvasY1 = (originalY1 / originalHeight) * canvas.height;
        const canvasX2 = (originalX2 / originalWidth) * canvas.width;
        const canvasY2 = (originalY2 / originalHeight) * canvas.height;
        
        const width = canvasX2 - canvasX1;
        const height = canvasY2 - canvasY1;
        
        const colorIndex = detection.class % colors.length;
        const color = isKeywordMatch ? "#00FF00" : colors[colorIndex];
        
        ctx.fillStyle = hexToRgba(color, 0.2);
        ctx.fillRect(canvasX1, canvasY1, width, height);
        
        ctx.strokeStyle = color;
        ctx.lineWidth = Math.max(Math.min(canvas.width, canvas.height) / 200, 2.5);
        ctx.strokeRect(canvasX1, canvasY1, width, height);
        
        const score = Math.round(detection.score * 100);
        const label = `${detection.className} - ${score}%`;
        const textWidth = ctx.measureText(label).width;
        const yText = canvasY1 - (fontSize + ctx.lineWidth);
        
        ctx.fillStyle = color;
        ctx.fillRect(
            canvasX1 - 1,
            yText < 0 ? 0 : yText,
            textWidth + ctx.lineWidth,
            fontSize + ctx.lineWidth
        );
        
        ctx.fillStyle = "#FFFFFF";
        ctx.fillText(label, canvasX1, yText < 0 ? 0 : yText);
    }
    
    updateDetectionStats(detectionCount, keywordMatchCount);
}

function hexToRgba(hex, alpha) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
        ? `rgba(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}, ${alpha})`
        : `rgba(255, 0, 0, ${alpha})`;
}

function updateDetectionStats(totalCount, keywordCount) {
    let statsDiv = document.getElementById("detectionStats");
    
    if (!statsDiv) {
        statsDiv = document.createElement("div");
        statsDiv.id = "detectionStats";
        statsDiv.style.position = "fixed";
        statsDiv.style.top = "10px";
        statsDiv.style.right = "10px";
        statsDiv.style.backgroundColor = "rgba(0,0,0,0.7)";
        statsDiv.style.color = "white";
        statsDiv.style.padding = "10px";
        statsDiv.style.borderRadius = "5px";
        statsDiv.style.zIndex = "1000";
        document.body.appendChild(statsDiv);
    }
    
    statsDiv.innerHTML = `
        <div>Total objects: ${totalCount}</div>
        ${keyword ? `<div>"${keyword}" objects: ${keywordCount}</div>` : ''}
    `;
}

function stopDetection() {
    clearInterval(detectionInterval);
    document.getElementById("start").disabled = videoElement ? false : true;
    document.getElementById("stop").disabled = true;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (videoElement) {
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    }
    
    const statsDiv = document.getElementById("detectionStats");
    if (statsDiv) statsDiv.remove();
    
    console.log("Detection stopped and resources cleared.");
    
    tf.engine().startScope();
    tf.engine().endScope();
    
    if (window.gc) {
        window.gc();
    }
}