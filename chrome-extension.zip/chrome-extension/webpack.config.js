const path = require('path');

module.exports = {
    entry: './detection/detection.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
    },
    mode: 'production'
};
